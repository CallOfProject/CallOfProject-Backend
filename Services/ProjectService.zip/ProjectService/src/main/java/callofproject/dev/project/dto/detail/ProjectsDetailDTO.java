package callofproject.dev.project.dto.detail;

import java.util.List;

public record ProjectsDetailDTO(List<ProjectDetailDTO> projects)
{
}
