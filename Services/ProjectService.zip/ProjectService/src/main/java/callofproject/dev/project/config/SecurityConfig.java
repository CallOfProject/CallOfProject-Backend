package callofproject.dev.project.config;

public class SecurityConfig
{
}
