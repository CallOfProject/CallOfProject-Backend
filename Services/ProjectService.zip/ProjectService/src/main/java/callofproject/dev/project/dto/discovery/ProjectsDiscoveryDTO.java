package callofproject.dev.project.dto.discovery;

import java.util.List;

public record ProjectsDiscoveryDTO(List<ProjectDiscoveryDTO> projects)
{
}
