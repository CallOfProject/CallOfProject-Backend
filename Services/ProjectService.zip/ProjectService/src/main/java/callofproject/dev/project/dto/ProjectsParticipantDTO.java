package callofproject.dev.project.dto;

import java.util.List;

public record ProjectsParticipantDTO(List<ProjectParticipantDTO> projectParticipants)
{
}
