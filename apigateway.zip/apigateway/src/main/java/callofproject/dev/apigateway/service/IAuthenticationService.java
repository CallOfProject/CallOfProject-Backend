package callofproject.dev.apigateway.service;

import callofproject.dev.apigateway.entity.User;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@FeignClient(name = "authentication-service", url = "http://localhost:4041/api/auth")
public interface IAuthenticationService
{

    Optional<User> findByUsername(String username);
}
