package callofproject.dev.apigateway.entity;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;


public class User
{

    private UUID userId;

    private String firstName;

    private String middleName;

    private String lastName;

    private String username;

    private String email;

    private String password;

    private LocalDate birthDate;

    private LocalDate creationDate = LocalDate.now();


    private UUID userProfileId;

    private boolean isAccountBlocked;

    private Set<Role> roles;

    public User()
    {
        if (this.roles == null)
        {
            this.roles = new HashSet();
        }

        this.isAccountBlocked = false;
        this.roles.add(new Role("ROLE_USER"));
    }

    public UUID getUserProfileId()
    {
        return this.userProfileId;
    }

    public void setUserProfileId(UUID userProfileId)
    {
        this.userProfileId = userProfileId;
    }

    public boolean isAccountBlocked()
    {
        return this.isAccountBlocked;
    }

    public void setAccountBlocked(boolean accountBlocked)
    {
        this.isAccountBlocked = accountBlocked;
    }

    public User(UUID userId, String username, String firstName, String middleName, String lastName, String email, String password, LocalDate birthDate, Role role)
    {
        this.userId = userId;
        this.username = username;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.birthDate = birthDate;
        this.isAccountBlocked = false;
        if (this.roles == null)
        {
            this.roles = new HashSet();
        }

        this.roles.add(role);
    }

    public User(String username, String firstName, String middleName, String lastName, String email, String password, LocalDate birthDate, Role role)
    {
        this.username = username;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.birthDate = birthDate;
        this.isAccountBlocked = false;
        if (this.roles == null)
        {
            this.roles = new HashSet();
        }

        this.roles.add(role);
    }

    public User(String username, String firstName, String lastName, String email, String password, LocalDate birthDate)
    {
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.birthDate = birthDate;
        this.middleName = "";
        this.isAccountBlocked = false;
        if (this.roles == null)
        {
            this.roles = new HashSet();
        }

        this.roles.add(new Role("ROLE_USER"));
    }

    public boolean getIsAccountBlocked()
    {
        return this.isAccountBlocked;
    }

    public void setUsername(String username)
    {
        this.username = username;
    }

    public UUID getUserId()
    {
        return this.userId;
    }

    public void setUserId(UUID userId)
    {
        this.userId = userId;
    }

    public String getFirstName()
    {
        return this.firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getMiddleName()
    {
        return this.middleName;
    }

    public void setMiddleName(String middleName)
    {
        this.middleName = middleName;
    }

    public String getLastName()
    {
        return this.lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public String getEmail()
    {
        return this.email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getPassword()
    {
        return this.password;
    }

    public void setPassword(String password)
    {
        this.password = password;
    }

    public LocalDate getBirthDate()
    {
        return this.birthDate;
    }

    public void setBirthDate(LocalDate birthDate)
    {
        this.birthDate = birthDate;
    }

    public LocalDate getCreationDate()
    {
        return this.creationDate;
    }

    public void setCreationDate(LocalDate creationDate)
    {
        this.creationDate = creationDate;
    }

    public UserProfile getUserProfile()
    {
        return this.userProfile;
    }

    public Set<Role> getRoles()
    {
        return this.roles;
    }

    public void setRoles(Set<Role> roles)
    {
        this.roles = roles;
    }

    public void setUserProfile(UserProfile userProfile)
    {
        this.userProfile = userProfile;
    }

    public String getUsername()
    {
        return this.username;
    }

    public void addRoleToUser(Role role)
    {
        boolean isExistsRole = this.roles.stream().anyMatch((r) -> {
            return r.getAuthority().equals(role.getAuthority());
        });
        if (!isExistsRole)
        {
            this.roles.add(role);
        }

    }

    public boolean isAdmin()
    {
        return this.roles.stream().map(Role::getName).anyMatch((role) -> {
            return role.equals(RoleEnum.ROLE_ADMIN.getRole());
        });
    }

    public boolean isRoot()
    {
        return this.roles.stream().map(Role::getName).anyMatch((role) -> {
            return role.equals(RoleEnum.ROLE_ROOT.getRole());
        });
    }

    public boolean isAdminOrRoot()
    {
        return this.roles.stream().map(Role::getName).anyMatch((role) -> {
            return role.equals(RoleEnum.ROLE_ADMIN.getRole()) || role.equals(RoleEnum.ROLE_ROOT.getRole());
        });
    }

    public String toString()
    {
        return "User{userId=" + this.userId + ", firstName='" + this.firstName + "', middleName='" + this.middleName + "', lastName='" + this.lastName + "', username='" + this.username + "', email='" + this.email + "', password='" + this.password + "', birthDate=" + this.birthDate + ", creationDate=" + this.creationDate + "}";
    }
}
