package callofproject.dev.apigateway.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

public class CsrfCookieFilter extends OncePerRequestFilter
{

    /**
     * Add csrf token to response header.
     *
     * @param request     represent the request
     * @param response    represent the response
     * @param filterChain represent the filter chain
     * @throws ServletException if any error occur
     * @throws IOException      if any error occur
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException
    {
        CsrfToken csrfToken = (CsrfToken) request.getAttribute(CsrfToken.class.getName());

        if (null != csrfToken.getHeaderName())
            response.setHeader(csrfToken.getHeaderName(), csrfToken.getToken());

        filterChain.doFilter(request, response);
    }

}