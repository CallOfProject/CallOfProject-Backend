//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package callofproject.dev.apigateway.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.security.core.GrantedAuthority;

public class Role implements GrantedAuthority
{

    private long m_roleId;

    private String m_name;


    public Role()
    {
    }


    public Role(String roleName)
    {
        this.m_name = roleName;
    }

    @JsonIgnore
    public long getRoleId()
    {
        return this.m_roleId;
    }

    public void setRoleId(long roleId)
    {
        this.m_roleId = roleId;
    }

    public String getName()
    {
        return this.m_name;
    }

    public void setName(String name)
    {
        this.m_name = name;
    }

    @JsonIgnore
    public String getAuthority()
    {
        return this.m_name;
    }
}
